import fileDownloader

class DownloadFile(fileDownloader.DownloadFile):
    pass